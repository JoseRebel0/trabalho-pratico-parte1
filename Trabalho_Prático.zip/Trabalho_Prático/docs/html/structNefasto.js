var structNefasto =
[
    [ "prox", "structNefasto.html#a2e66dd45c057a1126343c936655992b6", null ],
    [ "x", "structNefasto.html#aabf5cd10f98572d15b8d031322f66aba", null ],
    [ "y", "structNefasto.html#aa87cbe26a1d2e491c5f52a16cdcddf8e", null ]
];