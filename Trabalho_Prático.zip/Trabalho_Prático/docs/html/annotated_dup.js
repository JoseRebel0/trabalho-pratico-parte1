var annotated_dup =
[
    [ "Antena", "structAntena.html", "structAntena" ],
    [ "Nefasto", "structNefasto.html", "structNefasto" ]
];