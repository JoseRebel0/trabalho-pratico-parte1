var funcoes_8h =
[
    [ "carregarAntenasDoFicheiro", "funcoes_8h.html#a271cfc7165df8985a5defc51e624835b", null ],
    [ "criarAntena", "funcoes_8h.html#af76ca1c6ef0441952e3dc481b1fe437a", null ],
    [ "removerAntena", "funcoes_8h.html#a2a73579b9e1d789e83111a292e835704", null ]
];