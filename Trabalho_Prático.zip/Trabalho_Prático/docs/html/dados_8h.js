var dados_8h =
[
    [ "Antena", "structAntena.html", "structAntena" ],
    [ "Nefasto", "structNefasto.html", "structNefasto" ],
    [ "Antena", "dados_8h.html#a843ab8b81393e8ebb3eb6b76e349acc2", null ],
    [ "Nefasto", "dados_8h.html#ae690a2a29c460c7055653d2f38d277d4", null ]
];