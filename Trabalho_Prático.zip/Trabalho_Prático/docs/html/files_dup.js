var files_dup =
[
    [ "Data", "dir_e3d743d0ec9b4013b28b5d69101bc7fb.html", "dir_e3d743d0ec9b4013b28b5d69101bc7fb" ],
    [ "Functions", "dir_300faf08c8fb8933ad9035892dcb9a31.html", "dir_300faf08c8fb8933ad9035892dcb9a31" ],
    [ "Main", "dir_f4e982bca5d979afcf7d664254407d09.html", "dir_f4e982bca5d979afcf7d664254407d09" ]
];