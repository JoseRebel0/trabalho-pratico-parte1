var searchData=
[
  ['nefasto_0',['Nefasto',['../structNefasto.html',1,'']]]
];
