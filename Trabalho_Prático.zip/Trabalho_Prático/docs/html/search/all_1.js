var searchData=
[
  ['carregarantenasdoficheiro_0',['carregarAntenasDoFicheiro',['../funcoes_8c.html#a271cfc7165df8985a5defc51e624835b',1,'carregarAntenasDoFicheiro(const char *caminhoFicheiro):&#160;funcoes.c'],['../funcoes_8h.html#a271cfc7165df8985a5defc51e624835b',1,'carregarAntenasDoFicheiro(const char *caminhoFicheiro):&#160;funcoes.c']]],
  ['criarantena_1',['criarAntena',['../funcoes_8c.html#af76ca1c6ef0441952e3dc481b1fe437a',1,'criarAntena(int x, int y, char frequencia):&#160;funcoes.c'],['../funcoes_8h.html#af76ca1c6ef0441952e3dc481b1fe437a',1,'criarAntena(int x, int y, char frequencia):&#160;funcoes.c']]]
];
