var searchData=
[
  ['x_0',['x',['../structAntena.html#a3b196deb45a500d432ef7f7a653adbaf',1,'Antena::x'],['../structNefasto.html#aabf5cd10f98572d15b8d031322f66aba',1,'Nefasto::x']]]
];
