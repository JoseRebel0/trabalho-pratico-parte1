var searchData=
[
  ['frequencia_0',['frequencia',['../structAntena.html#a98d94cd90b6d9288fc867dbe7a6b6f41',1,'Antena']]]
];
