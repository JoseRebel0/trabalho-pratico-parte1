var searchData=
[
  ['y_0',['y',['../structAntena.html#a7166c31d6fd9c3607b300ee0dc6371ba',1,'Antena::y'],['../structNefasto.html#aa87cbe26a1d2e491c5f52a16cdcddf8e',1,'Nefasto::y']]]
];
