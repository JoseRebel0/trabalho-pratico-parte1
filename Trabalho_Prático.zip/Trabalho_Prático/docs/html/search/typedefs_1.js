var searchData=
[
  ['nefasto_0',['Nefasto',['../dados_8h.html#ae690a2a29c460c7055653d2f38d277d4',1,'dados.h']]]
];
