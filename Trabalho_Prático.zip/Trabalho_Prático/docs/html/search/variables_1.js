var searchData=
[
  ['lista_0',['lista',['../menu_8c.html#aee5fb13367bf087f465382e6b9477acd',1,'menu.c']]]
];
