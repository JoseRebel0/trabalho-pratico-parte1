var searchData=
[
  ['frequencia_0',['frequencia',['../structAntena.html#a98d94cd90b6d9288fc867dbe7a6b6f41',1,'Antena']]],
  ['funcoes_2ec_1',['funcoes.c',['../funcoes_8c.html',1,'']]],
  ['funcoes_2eh_2',['funcoes.h',['../funcoes_8h.html',1,'']]]
];
