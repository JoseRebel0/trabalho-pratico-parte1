var indexSectionsWithContent =
{
  0: "acdflmnprxy",
  1: "an",
  2: "dfm",
  3: "clmr",
  4: "flpxy",
  5: "an"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Estruturas de dados",
  2: "Ficheiros",
  3: "Funções",
  4: "Variáveis",
  5: "Definições de tipos"
};

