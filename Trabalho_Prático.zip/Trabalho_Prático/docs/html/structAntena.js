var structAntena =
[
    [ "frequencia", "structAntena.html#a98d94cd90b6d9288fc867dbe7a6b6f41", null ],
    [ "prox", "structAntena.html#a20010d47a4aa05eee8fd6412a96e0b69", null ],
    [ "x", "structAntena.html#a3b196deb45a500d432ef7f7a653adbaf", null ],
    [ "y", "structAntena.html#a7166c31d6fd9c3607b300ee0dc6371ba", null ]
];