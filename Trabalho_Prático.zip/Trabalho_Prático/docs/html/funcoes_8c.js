var funcoes_8c =
[
    [ "carregarAntenasDoFicheiro", "funcoes_8c.html#a271cfc7165df8985a5defc51e624835b", null ],
    [ "criarAntena", "funcoes_8c.html#af76ca1c6ef0441952e3dc481b1fe437a", null ],
    [ "listarAntenas", "funcoes_8c.html#ad8e25ea7e05f77d363c12d6f63e7ebde", null ],
    [ "removerAntena", "funcoes_8c.html#a2a73579b9e1d789e83111a292e835704", null ]
];